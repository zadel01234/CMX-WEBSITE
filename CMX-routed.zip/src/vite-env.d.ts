/// <reference types="vite/client" />

declare module '*.webp' { const src: string; export default src; }
declare module '*.jpg'  { const src: string; export default src; }
declare module '*.JPG'  { const src: string; export default src; }
declare module '*.jpeg' { const src: string; export default src; }
declare module '*.png'  { const src: string; export default src; }
